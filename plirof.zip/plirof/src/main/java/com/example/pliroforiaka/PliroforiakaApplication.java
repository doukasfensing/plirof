package com.example.pliroforiaka;

import consumers.Consumer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import sensors.Etot;
import sensors.Sensor;
import sensors.Wtot;

@SpringBootApplication
public class PliroforiakaApplication {
	//Round timestamp to the nearest quarter of hour
	public static long roundToNearestQuarterHour(long timestamp){
		return timestamp - (timestamp % 900000);
	}

	public static void main(String[] args) {
		SpringApplication.run(PliroforiakaApplication.class, args);


		long timestamp = roundToNearestQuarterHour(System.currentTimeMillis());

		Sensor TH1 = new Sensor();
		TH1.setName("TH1");
		TH1.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465cd");
		TH1.setInterval(1);
		TH1.setAggregationMethod(1);
		TH1.setDataValueRange(new int[]{12, 35});

		Sensor TH2 = new Sensor();
		TH2.setName("TH2");
		TH2.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465ce");
		TH2.setInterval(1);
		TH2.setAggregationMethod(1);
		TH2.setDataValueRange(new int[]{12, 35});

		Sensor HVAC1 = new Sensor();
		HVAC1.setName("HVAC1");
		HVAC1.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465cf");
		HVAC1.setInterval(1);
		HVAC1.setAggregationMethod(2);
		HVAC1.setDataValueRange(new int[]{0, 100});

		Sensor HVAC2 = new Sensor();
		HVAC2.setName("HVAC2");
		HVAC2.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d0");
		HVAC2.setInterval(1);
		HVAC2.setAggregationMethod(2);
		HVAC2.setDataValueRange(new int[]{0, 200});

		Sensor MiAC1 = new Sensor();
		MiAC1.setName("MiAC1");
		MiAC1.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d1");
		MiAC1.setInterval(1);
		MiAC1.setAggregationMethod(2);
		MiAC1.setDataValueRange(new int[]{0, 150});

		Sensor MiAC2 = new Sensor();
		MiAC2.setName("MiAC2");
		MiAC2.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d2");
		MiAC2.setInterval(1);
		MiAC2.setAggregationMethod(2);
		MiAC2.setDataValueRange(new int[]{0, 200});

		Etot Etot = new Etot();
		Etot.setName("Etot");
		Etot.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d3");
		Etot.setInterval(2);
		Etot.setAggregationMethod(3);

		Sensor Mov1 = new Sensor();
		Mov1.setName("Mov1");
		Mov1.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d4");
		Mov1.setInterval(0);
		Mov1.setAggregationMethod(2);
		Mov1.setDataValueRange(new int[]{0, 1});

		Sensor W1 = new Sensor();
		W1.setName("W1");
		W1.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d5");
		W1.setInterval(1);
		W1.setAggregationMethod(2);
		W1.setDataValueRange(new int[]{0, 1});

		Wtot Wtot = new Wtot();
		Wtot.setName("Wtot");
		Wtot.setUuid("7f091d9a-b22f-45c6-a2c7-9126c98465d6");
		Wtot.setInterval(2);
		Wtot.setAggregationMethod(3);

		Sensor[] sensors = new Sensor[]{TH1, TH2, HVAC1, HVAC2, MiAC1, MiAC2, Etot, Mov1, W1, Wtot};

		//Consumer consumer = new Consumer();
		//consumer.consumeMessage();

		for(int i=0; ; i++){
			//Add a quarter of hour to timestamp
			timestamp += 900000;

			//Convert times to YYYY-MM-DDTHH:MM:SSZ format
			String time = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'").format(new java.util.Date(timestamp));



			//Convert timestamp to microseconds
			long tempTimestamp = timestamp * 1000;

			for(Sensor sensor : sensors){
				System.out.println(sensor.getName() + " "  + time);
				sensor.setTimestamp(time);
				sensor.setValue();

				if(sensor.getInterval() == 1) {
					if(sensor.getName().equals("W1") && i % 20 == 0){
						long twoDaysTimestamp = timestamp - 2 * 86400000;
						String twoDaysTime = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'").format(new java.util.Date(twoDaysTimestamp));
						sensor.setTimestamp(twoDaysTime);
						sensor.setValue();
					}
					else if(sensor.getName().equals("W1") && i % 120 == 0){
						long twoDaysTimestamp = timestamp - 10 * 86400000;
						String twoDaysTime = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'").format(new java.util.Date(twoDaysTimestamp));
						sensor.setTimestamp(twoDaysTime);
						sensor.setValue();
					}
					else
						sensor.produceMessage();
				}
				if(sensor.getInterval() == 2 && i %  96 == 0)
					sensor.produceMessage();
				if(sensor.getInterval() == 0) {
					if (sensor.getValue() < 0.06)
						sensor.produceMessage();
				}
			}

			//Pause system for 1 second
				/*try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}*/

		}

	}

}
