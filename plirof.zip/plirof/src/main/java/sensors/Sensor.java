package sensors;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

@lombok.Data
public class Sensor {
    protected String name;
    protected String uuid;
    protected double value;
    protected int interval;
    protected int aggregationMethod;
    protected int[] dataValueRange;
    protected String timestamp;

    public void setValue(){
        //Return rundom number between dataValueRange[0] and dataValueRange[1]
        this.value = Math.random() * (dataValueRange[1] - dataValueRange[0]) + dataValueRange[0];

        //Round value to 2 decimal places
        this.value = Math.round(this.value * 100.0) / 100.0;
    }

    private static final String QUEUE_NAME = "pliroforiaka";
    public void produceMessage(){
        Message message = new Message(uuid, value, timestamp);

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        try {
            factory.setHost("localhost");
            factory.setUsername("guest");
            factory.setPassword("guest");
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();
            channel.queueDeclare(QUEUE_NAME, true, false, false, null);

            //Convert Message message to json using Object Mapper
            ObjectMapper mapper = new ObjectMapper();
            String message1 = mapper.writeValueAsString(message);

            System.out.println(message1);

            channel.basicPublish("", QUEUE_NAME, null, message1.getBytes("UTF-8"));
            channel.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
