package com.example.pliroforiaka;

import consumers.Consumer;
import org.apache.flink.shaded.curator5.com.google.common.base.Splitter;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import sensors.Sensor;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.rabbitmq.RMQSource;
import org.apache.flink.streaming.connectors.rabbitmq.common.RMQConnectionConfig;

@SpringBootTest
class PliroforiakaApplicationTests {
	@Test
	public void testConsumeMessage(){
		Consumer consumer = new Consumer();
		consumer.consumeMessage();
	}
	@Test
	public void testSetValue(){
		Sensor sensor = new Sensor();
		sensor.setDataValueRange(new int[]{2,5});
		sensor.setValue();
	}
	@Test
	public void testMessage(){
		Sensor sensor = new Sensor();
		sensor.setUuid("1234");
		sensor.setValue(1.0);
		sensor.setInterval(1);
		sensor.setAggregationMethod(1);
		sensor.setDataValueRange(new int[]{1,2,3,4,5});
		sensor.setTimestamp("2020-05-05T12:00:00Z");
		sensor.produceMessage();
		sensor.produceMessage();
		sensor.produceMessage();
		sensor.produceMessage();
	}
	public void testSensors(){
		Sensor sensor = new Sensor();
		sensor.setUuid("1234");
		sensor.setValue(1.0);
		sensor.setInterval(1);
		sensor.setAggregationMethod(1);
		sensor.setDataValueRange(new int[]{1,2,3,4,5});
	}

	@Test
	void
	contextLoads() {
	}

}
